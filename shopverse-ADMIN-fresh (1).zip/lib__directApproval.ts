import { collection, doc, getDoc, getDocs, limit, query, serverTimestamp, where, writeBatch } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase/config';
import { friendlyError } from '@/lib/errors';
import { buildApproval, buildNotification, buildRejection, type ApplicationFields } from '@/lib/approvalDocs';

const s = (v: unknown) => (typeof v === 'string' ? v : '');

/**
 * Approve / reject a seller application straight from the admin panel: NO Cloud Function, NO Blaze plan, NO extra server.
 * Firestore rules (admin only) check that approving creates, in ONE atomic batch: application -> approved, roles/{uid}=seller, stores/{uid}, storePrivate/{uid} and the address claim.
 * Plain-language Errors are thrown for the admin. The applicant's email is not checked here (only the server can read it); the admin's decision is the review.
 */
export async function reviewDirect(applicationId: string, action: 'approve' | 'reject', note: string): Promise<{ ok: boolean; storeId: string; products: number }> {
  const adminId = auth().currentUser?.uid;
  if (!adminId) throw new Error('Please sign in again.');
  const appRef = doc(db(), 'sellerApplications', applicationId);
  try {
    const snap = await getDoc(appRef);
    if (!snap.exists()) throw new Error('Application not found.');
    const a = snap.data();
    if (a.status !== 'pending') throw new Error(`Only pending applications can be decided (this one is ${s(a.status) || 'unknown'}).`);
    const b = writeBatch(db());
    if (action === 'reject') {
      if (note.trim().length < 5) throw new Error('Give a reason (at least 5 characters). The applicant will see it.');
      b.update(appRef, buildRejection(adminId, note.trim(), serverTimestamp()));
      b.set(doc(collection(db(), 'notifications')), buildNotification(applicationId, false, s(a.storeName), note.trim(), serverTimestamp()));
      await b.commit();
      return { ok: true, storeId: '', products: 0 };
    }
    const uid = applicationId;
    if ((await getDoc(doc(db(), 'roles', uid))).exists()) throw new Error('This account already has a role, so it cannot be converted to a seller.');
    if ((await getDoc(doc(db(), 'stores', uid))).exists() || !(await getDocs(query(collection(db(), 'stores'), where('ownerId', '==', uid), limit(1)))).empty) throw new Error('This account already owns a store.');
    const slug = s(a.slug);
    if ((await getDoc(doc(db(), 'storeSlugs', slug))).exists() || !(await getDocs(query(collection(db(), 'stores'), where('slug', '==', slug), limit(1)))).empty) throw new Error(`The store address “${slug}” is already taken. Reject with a note asking for a different address.`);
    const d = buildApproval(uid, adminId, a as unknown as ApplicationFields, serverTimestamp());
    b.update(appRef, d.application);
    b.set(doc(db(), 'roles', uid), d.role);
    b.set(doc(db(), 'stores', uid), d.store);
    b.set(doc(db(), 'storePrivate', uid), d.storePrivate);
    b.set(doc(db(), 'storeSlugs', slug), d.slugClaim);
    b.set(doc(collection(db(), 'notifications')), buildNotification(uid, true, s(a.storeName), '', serverTimestamp()));
    b.set(doc(collection(db(), 'adminLogs')), { adminId, action: 'seller.approve', targetType: 'sellerApplication', targetId: uid, note: 'via admin panel button', createdAt: serverTimestamp() });
    await b.commit();
    return { ok: true, storeId: uid, products: 0 };
  } catch (e) {
    if (e instanceof Error && !('code' in e)) throw e;
    if ((e as { code?: string })?.code === 'permission-denied') throw new Error('Firestore refused this. Publish the latest firestore.rules (Firebase Console → Firestore → Rules) and make sure your account has the admin role.');
    throw new Error(friendlyError(e));
  }
}
