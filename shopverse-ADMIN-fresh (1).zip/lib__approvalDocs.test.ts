import { describe, expect, it } from 'vitest';
import { buildApproval, buildNotification, buildRejection } from './approvalDocs';

const app = { storeName: 'Ann Shop', slug: 'ann-shop', description: 'd', city: 'Dhaka', country: 'Bangladesh', phone: '555555', email: 'a@a.co', address: '1 Road' };
const TS = Symbol('ts');
describe('buildApproval (admin Approve button)', () => {
  const d = buildApproval('u1', 'admin1', app, TS);
  it('approves the application, linking the store id to the applicant uid and recording the admin', () => {
    expect([d.application.status, d.application.storeId, d.application.reviewedBy]).toEqual(['approved', 'u1', 'admin1']);
  });
  it('grants exactly the seller role to the applicant, never a staff role', () => {
    expect(d.role.role).toBe('seller');
    expect(Object.keys(d.role).sort()).toEqual(['role', 'updatedAt', 'updatedBy']);
  });
  it('creates a store owned by the applicant with zeroed counters', () => {
    expect([d.store.ownerId, d.store.applicationId, d.store.status, d.store.slug]).toEqual(['u1', 'u1', 'approved', 'ann-shop']);
    expect([d.store.shippingFee, d.store.ratingCount, d.store.followerCount, d.store.salesCount]).toEqual([0, 0, 0, 0]);
    expect('phone' in d.store).toBe(false);
  });
  it('keeps contact details private and claims the address for the applicant', () => {
    expect([d.storePrivate.phone, d.storePrivate.email, d.storePrivate.address]).toEqual(['555555', 'a@a.co', '1 Road']);
    expect(Object.keys(d.slugClaim).sort()).toEqual(['createdAt', 'uid']);
    expect(d.slugClaim.uid).toBe('u1');
  });
  it('rejection only touches decision fields', () => {
    expect(Object.keys(buildRejection('admin1', 'bad photos', TS)).sort()).toEqual(['reviewNote', 'reviewedAt', 'reviewedBy', 'status', 'updatedAt']);
  });
  it('notifies the applicant: approved goes to the Seller Center, rejected shows the reason', () => {
    const ok = buildNotification('u1', true, 'Ann Shop', '', TS), no = buildNotification('u1', false, 'Ann Shop', 'bad photos', TS);
    expect([ok.userId, ok.type, ok.link, ok.read]).toEqual(['u1', 'seller_approve', '/seller', false]);
    expect([no.type, no.body, no.link]).toEqual(['seller_reject', 'bad photos', '/become-seller']);
  });
});
