import { describe, expect, it } from 'vitest';
import { buildAnnouncementNotification, buildProductNotification, chunk } from './notifyDocs';

const TS = Symbol('ts');
describe('admin notifications', () => {
  it('announcement: promo vs important use the right type and category, unread, no image', () => {
    const p = buildAnnouncementNotification('u1', 'promotion', 'Sale', 'Big sale', '/shop', TS);
    const i = buildAnnouncementNotification('u1', 'important', 'Notice', 'Maintenance', '', TS);
    expect([p.type, p.category, p.read, p.link]).toEqual(['announcement_promo', 'promotions', false, '/shop']);
    expect([i.type, i.category]).toEqual(['announcement_important', 'system']);
  });
  it('product decision goes to the seller with a link to that product only', () => {
    const n = buildProductNotification('seller1', 'p123', 'Red shoes', 'rejected', 'blurry photo', TS);
    expect([n.userId, n.type, n.category, n.link]).toEqual(['seller1', 'product_rejected', 'seller', '/seller/products/p123/edit']);
    expect(/blurry photo/.test(n.body)).toBe(true);
    expect(buildProductNotification('s', 'p', 'x', 'suspended', '', TS).category).toBe('system');
    expect(buildProductNotification('s', 'p', 'x', 'approved', '', TS).title).toBe('Product approved');
  });
  it('only the documented keys are written (matches the rules)', () => {
    expect(Object.keys(buildProductNotification('s', 'p', 'x', 'approved', '', TS)).sort()).toEqual(['body', 'category', 'createdAt', 'image', 'link', 'read', 'relatedId', 'relatedType', 'title', 'type', 'userId']);
  });
  it('chunk splits recipients into batches of at most 400', () => {
    const ids = Array.from({ length: 950 }, (_, i) => String(i));
    expect(chunk(ids).map((c) => c.length)).toEqual([400, 400, 150]);
  });
});
