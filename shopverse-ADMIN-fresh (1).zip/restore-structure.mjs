// Rebuilds the project's folders from "flat" files. Phone file pickers (Android Chrome, GitHub web upload) upload loose files but skip folders.
// In the FLAT ZIP every file sits at the repository root with "/" written as "__" (app__login__page.tsx -> app/login/page.tsx),
// and dot-files are written as "dot__name" (dot__eslintrc.json -> .eslintrc.json). Runs automatically before every build. With real folders it changes nothing.
import { existsSync, mkdirSync, readdirSync, renameSync } from 'node:fs';
import { dirname, join } from 'node:path';
const ROOTS = new Set(['android', 'app', 'components', 'config', 'docs', 'functions', 'hooks', 'lib', 'public', 'scripts', 'services', 'tests', 'types', 'utils']);
let moved = 0;
for (const name of readdirSync('.')) {
  if (name.startsWith('dot__')) { renameSync(name, '.' + name.slice(5)); moved++; continue; }
  if (!name.includes('__')) continue;
  const parts = name.split('__');
  if (!ROOTS.has(parts[0])) continue;
  const target = join(...parts);
  mkdirSync(dirname(target), { recursive: true });
  renameSync(name, target);
  moved++;
}
if (moved) console.log(`restore-structure: restored ${moved} files.`);
if (!existsSync('app')) { console.error('ERROR: the "app" folder is missing and no app__* files were found. Upload ALL files from the ZIP, then redeploy.'); process.exit(1); }
