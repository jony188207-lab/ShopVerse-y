/**
 * Pure helpers for the Adsterra settings page (unit tested). Ad code is third-party JavaScript: it is NEVER inserted into this
 * panel's DOM or the storefront's DOM. The storefront renders it inside a sandboxed iframe without allow-same-origin, and the
 * rules let only a super admin create or change it.
 */
export const AD_CODE_MAX = 20000; // firestore.rules adOk
export const AD_DEVICES = ['all', 'mobile', 'desktop'] as const;
export type AdDevice = (typeof AD_DEVICES)[number];

/** Adsterra banner snippets declare their size in `atOptions = {'height':90,'width':728,...}`. Used only to pre-fill the size fields. */
export function sizeFromCode(code: string): { width?: number; height?: number } {
  const num = (k: string) => {
    const m = new RegExp(`['"]?${k}['"]?\\s*:\\s*['"]?(\\d{2,4})`, 'i').exec(code);
    return m ? Number(m[1]) : undefined;
  };
  return { width: num('width'), height: num('height') };
}

export interface AdInput { networkName: string; adCode: string; width: number; height: number; device: string }

/** Mirrors the numeric/length limits in firestore.rules (adOk). Returns a message, or '' when valid. */
export function validateAd(a: AdInput): string {
  const name = a.networkName.trim();
  if (name.length < 1 || name.length > 60) return 'Network name must be 1–60 characters.';
  const code = a.adCode.trim();
  if (!code) return 'Paste the ad code from Adsterra.';
  if (code.length > AD_CODE_MAX) return `The ad code is too long (${code.length} of ${AD_CODE_MAX} characters).`;
  if (!/<(script|iframe)\b/i.test(code)) return 'This does not look like ad code: it must contain a <script> or <iframe> tag.';
  if (!Number.isFinite(a.width) || a.width < 50 || a.width > 1200) return 'Width must be between 50 and 1200.';
  if (!Number.isFinite(a.height) || a.height < 30 || a.height > 600) return 'Height must be between 30 and 600.';
  if (!(AD_DEVICES as readonly string[]).includes(a.device)) return 'Choose a device.';
  return '';
}

/** Short, safe description of a stored ad for lists. Never returns the code itself. */
export const describeCode = (code: string): string => `${code.length} characters of ad code (hidden)`;

/** Protocol-relative script URLs (//host/…) are common in ad snippets; the storefront iframe resolves them against https. Warn about plain http. */
export const hasInsecureScript = (code: string): boolean => /<script[^>]+src\s*=\s*['"]http:\/\//i.test(code);
