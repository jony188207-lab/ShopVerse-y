/** Pure notification builders (no Firebase imports, unit-testable). Shapes match what the Cloud Functions write and what firestore.rules allows from an admin. */
export type Audience = 'all' | 'sellers' | 'user';
export const MAX_RECIPIENTS = 2000;
export const BATCH = 400;

export const buildAnnouncementNotification = <T,>(uid: string, kind: 'promotion' | 'important', title: string, body: string, link: string, ts: T) => ({
  userId: uid, type: kind === 'important' ? 'announcement_important' : 'announcement_promo', category: kind === 'important' ? 'system' : 'promotions',
  title, body, image: '', relatedId: '', relatedType: '', link, read: false, createdAt: ts,
});

export type ProductDecision = 'approved' | 'rejected' | 'suspended';
export const buildProductNotification = <T,>(sellerId: string, productId: string, productTitle: string, status: ProductDecision, note: string, ts: T) => {
  const t = productTitle.slice(0, 60);
  const n = note ? ` Note: ${note}` : '';
  const text = {
    approved: { title: 'Product approved', body: `“${t}” is now live.` },
    rejected: { title: 'Product rejected', body: `“${t}” needs changes.${n}` },
    suspended: { title: 'Product suspended', body: `“${t}” was suspended.${n}` },
  }[status];
  return {
    userId: sellerId, type: `product_${status}`, category: status === 'suspended' ? 'system' : 'seller', title: text.title, body: text.body.slice(0, 500),
    image: '', relatedId: productId, relatedType: 'product', link: `/seller/products/${productId}/edit`, read: false, createdAt: ts,
  };
};

/** Split ids into batches the rules/Firestore accept (500 writes max; keep room for the history + audit docs). */
export function chunk<X>(ids: X[], size = BATCH): X[][] { const out: X[][] = []; for (let i = 0; i < ids.length; i += size) out.push(ids.slice(i, i + size)); return out; }
