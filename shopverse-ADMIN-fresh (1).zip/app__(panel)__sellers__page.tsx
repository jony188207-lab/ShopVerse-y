'use client';
import { useState } from 'react';
import { collection, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { reviewSellerApplication } from '@/lib/callables';
import { sellerApiUrl } from '@/lib/sellerApi';
import { fmtDate, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Notice } from '@/components/ui/States';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'pending' | 'approved' | 'rejected' | 'suspended';
type Action = 'approve' | 'reject' | 'suspend' | 'reactivate';
const TABS: { id: Tab; label: string }[] = [{ id: 'pending', label: 'Pending' }, { id: 'approved', label: 'Approved' }, { id: 'suspended', label: 'Suspended' }, { id: 'rejected', label: 'Rejected' }];

interface App { id: string; storeName: string; ownerName: string; slug: string; email: string; phone: string; city: string; country: string; address: string; description: string; returnPolicy: string; shippingInfo: string; reviewNote: string; createdAt: unknown }
const mapApp = (d: QueryDocumentSnapshot): App => {
  const x = d.data();
  return { id: d.id, storeName: str(x.storeName), ownerName: str(x.ownerName), slug: str(x.slug), email: str(x.email), phone: str(x.phone), city: str(x.city), country: str(x.country), address: str(x.address), description: str(x.description), returnPolicy: str(x.returnPolicy), shippingInfo: str(x.shippingInfo), reviewNote: str(x.reviewNote), createdAt: x.createdAt };
};

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('pending');
  const [dialog, setDialog] = useState<{ app: App; action: 'reject' | 'suspend' } | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(tab, () => query(collection(db(), 'sellerApplications'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapApp);

  const run = async (app: App, action: Action, note = '') => {
    setBusyId(app.id);
    try {
      await reviewSellerApplication(app.id, action, note);
      toast(`${app.storeName}: ${action} done.`, 'success');
      await list.reload();
    } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };
  const quick = (app: App, action: 'approve' | 'reactivate') => {
    const msg = action === 'approve' ? `Approve “${app.storeName}”? This creates the store and gives the applicant the seller role.` : `Reactivate “${app.storeName}”?`;
    if (user && window.confirm(msg)) void run(app, action).catch(() => undefined);
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Seller applications</h1>
      {sellerApiUrl()
        ? <Notice>Decisions run through your free Cloudflare Worker, which re-checks your admin role on the server. Approval also requires the applicant&apos;s verified email.</Notice>
        : <Notice>Approve and Reject work directly from this page (no Cloud Functions or billing needed); Firestore rules re-check that you are an admin. Suspend / Reactivate also hide products, so they still need the Cloud Function (Blaze) or the Worker. Email verification is not checked here, so confirm the applicant looks genuine before approving.</Notice>}
      <Tabs label="Application status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle={`No ${tab} applications`} hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((a) => (
          <Card key={a.id} className="space-y-2">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div><p className="font-bold">{a.storeName}</p><p className="text-xs text-navy-500 dark:text-navy-100">/{a.slug} · {a.ownerName} · {a.email} · applied {fmtDate(a.createdAt)}</p></div>
              <Badge>{tab}</Badge>
            </div>
            <details className="text-sm"><summary className="cursor-pointer text-brand-purple">Details</summary>
              <dl className="mt-2 space-y-1">
                <div><dt className="inline font-semibold">Phone: </dt><dd className="inline">{a.phone}</dd></div>
                <div><dt className="inline font-semibold">Location: </dt><dd className="inline">{[a.address, a.city, a.country].filter(Boolean).join(', ')}</dd></div>
                <div><dt className="font-semibold">Description</dt><dd className="whitespace-pre-wrap">{a.description || '—'}</dd></div>
                <div><dt className="font-semibold">Return policy</dt><dd className="whitespace-pre-wrap">{a.returnPolicy || '—'}</dd></div>
                <div><dt className="font-semibold">Shipping info</dt><dd className="whitespace-pre-wrap">{a.shippingInfo || '—'}</dd></div>
              </dl>
            </details>
            {a.reviewNote ? <p className="text-sm"><span className="font-semibold">Last decision note:</span> {a.reviewNote}</p> : null}
            <div className="flex flex-wrap gap-2">
              {tab === 'pending' ? <><Button small loading={busyId === a.id} onClick={() => quick(a, 'approve')}>Approve</Button><Button small variant="danger" disabled={busyId === a.id} onClick={() => setDialog({ app: a, action: 'reject' })}>Reject…</Button></> : null}
              {tab === 'approved' ? <Button small variant="danger" disabled={busyId === a.id} onClick={() => setDialog({ app: a, action: 'suspend' })}>Suspend…</Button> : null}
              {tab === 'suspended' ? <Button small loading={busyId === a.id} onClick={() => quick(a, 'reactivate')}>Reactivate</Button> : null}
            </div>
          </Card>
        ))}
      </ListStates>
      {dialog ? <ReasonDialog title={`${dialog.action === 'reject' ? 'Reject' : 'Suspend'} “${dialog.app.storeName}”`} confirmLabel={dialog.action === 'reject' ? 'Reject' : 'Suspend'} danger
        onConfirm={(r) => run(dialog.app, dialog.action, r)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function SellersPage() { return <Require level="admin"><Inner /></Require>; }
