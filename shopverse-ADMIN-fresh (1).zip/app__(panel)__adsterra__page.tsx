'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { collection, doc, getDocs, limit, query, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/errors';
import { atLeast } from '@/lib/permissions';
import { fmtDate, fromInputValue, num, str, toDate, toInputValue } from '@/lib/format';
import { AD_CODE_MAX, describeCode, hasInsecureScript, sizeFromCode, validateAd } from '@/lib/adsterra';
import { Require } from '@/components/Require';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field, Select, TextArea } from '@/components/ui/Field';
import { EmptyState, ErrorState, LoadingState, Notice } from '@/components/ui/States';

/** The storefront reads adNetworkSettings (placement "bottom"). This page manages ONE Adsterra slot with a fixed document id. */
const SLOT_ID = 'adsterra-bottom';
interface Ad { id: string; networkName: string; adCode: string; width: number; height: number; device: string; active: boolean; startDate: Date | null; endDate: Date | null }
interface Draft { networkName: string; adCode: string; width: string; height: string; device: string; active: boolean; startDate: string; endDate: string }
const EMPTY: Draft = { networkName: 'Adsterra', adCode: '', width: '728', height: '90', device: 'all', active: false, startDate: '', endDate: '' };

// Same restrictions as the storefront: no allow-same-origin, so ad scripts cannot reach this panel's cookies, storage or Firebase session.
const SANDBOX = 'allow-scripts allow-popups allow-popups-to-escape-sandbox';
const previewDoc = (code: string) => `<!doctype html><html><head><meta charset="utf-8"><base target="_blank"><style>html,body{margin:0;overflow:hidden;background:transparent}body{display:flex;justify-content:center}</style></head><body>${code}</body></html>`;

function Inner() {
  const { user, role } = useAuth();
  const toast = useToast();
  const isSuper = atLeast(role, 'super');
  const [ads, setAds] = useState<Ad[] | null>(null);
  const [error, setError] = useState('');
  const [draft, setDraft] = useState<Draft | null>(null);
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<Draft | null>(null);

  const load = useCallback(async () => {
    setError('');
    try {
      const snap = await getDocs(query(collection(db(), 'adNetworkSettings'), limit(20)));
      setAds(snap.docs.map((d) => { const x = d.data(); return { id: d.id, networkName: str(x.networkName), adCode: str(x.adCode), width: num(x.width, 728), height: num(x.height, 90), device: str(x.device, 'all'), active: x.active === true, startDate: toDate(x.startDate), endDate: toDate(x.endDate) }; }));
    } catch (e) { setError(friendlyError(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const log = (batch: ReturnType<typeof writeBatch>, action: string, id: string, note: string) => {
    if (user) batch.set(doc(collection(db(), 'adminLogs')), { adminId: user.uid, action, targetType: 'ad', targetId: id, note, createdAt: serverTimestamp() });
  };

  // Rules: any admin may pause/resume (only active + updatedAt change); only a super admin may change the code.
  const setActive = async (a: Ad, active: boolean) => {
    setBusy(true);
    try {
      const batch = writeBatch(db());
      batch.update(doc(db(), 'adNetworkSettings', a.id), { active, updatedAt: serverTimestamp() });
      log(batch, active ? 'ad.enable' : 'ad.disable', a.id, a.networkName);
      await batch.commit();
      toast(active ? 'Ad is on. It appears on the website within a minute or after a refresh.' : 'Ad is off.', 'success');
      await load();
    } catch (e) { toast(friendlyError(e), 'error'); } finally { setBusy(false); }
  };

  const edit = (a: Ad | null) => {
    setFormError(''); setPreview(null);
    setDraft(a ? { networkName: a.networkName, adCode: a.adCode, width: String(a.width), height: String(a.height), device: a.device, active: a.active, startDate: toInputValue(a.startDate), endDate: toInputValue(a.endDate) } : EMPTY);
  };

  const onCode = (d: Draft, adCode: string) => {
    const s = sizeFromCode(adCode);
    setDraft({ ...d, adCode, width: s.width ? String(s.width) : d.width, height: s.height ? String(s.height) : d.height });
    setPreview(null);
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft || !user) return;
    const width = Number(draft.width), height = Number(draft.height);
    const msg = validateAd({ networkName: draft.networkName, adCode: draft.adCode, width, height, device: draft.device });
    if (msg) return setFormError(msg);
    const start = fromInputValue(draft.startDate), end = fromInputValue(draft.endDate);
    if (start && end && end <= start) return setFormError('The end must be after the start.');
    setFormError(''); setBusy(true);
    try {
      const exists = ads?.some((a) => a.id === SLOT_ID);
      const data = { networkName: draft.networkName.trim(), adCode: draft.adCode.trim(), adUrl: '', placement: 'bottom', device: draft.device, width, height, active: draft.active, startDate: start, endDate: end, updatedAt: serverTimestamp() };
      const batch = writeBatch(db());
      if (exists) batch.update(doc(db(), 'adNetworkSettings', SLOT_ID), data);
      else batch.set(doc(db(), 'adNetworkSettings', SLOT_ID), { ...data, createdAt: serverTimestamp() });
      log(batch, exists ? 'ad.update' : 'ad.create', SLOT_ID, `${data.networkName}: ${describeCode(data.adCode)}`); // the code itself is never written to the log
      await batch.commit();
      toast('Saved. The website picks up the new code on its next load.', 'success');
      setDraft(null); setPreview(null);
      await load();
    } catch (err) { setFormError(friendlyError(err)); } finally { setBusy(false); }
  };

  if (error) return <ErrorState message={error} action={<Button onClick={() => void load()}>Try again</Button>} />;
  if (!ads) return <LoadingState />;
  const live = ads.filter((a) => a.active);
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-extrabold">Adsterra settings</h1>
        {isSuper ? <Button onClick={() => edit(ads.find((a) => a.id === SLOT_ID) ?? null)}>{ads.some((a) => a.id === SLOT_ID) ? 'Change ad code' : 'Add ad code'}</Button> : null}
      </div>
      <Notice>
        This is the banner at the <strong>bottom</strong> of the ShopVerse website. The code runs only inside a sandboxed frame on the website, never directly in the page, and is not shown to visitors as text.
        {isSuper ? '' : ' Admins can switch the ad on or off; only a super admin can change the code.'} The global ads switch is in Settings (super admin).
      </Notice>
      {live.length > 1 ? <Notice tone="warn">{live.length} ads are active for the bottom slot. The website shows only one of them, chosen automatically. Turn the others off.</Notice> : null}
      {draft ? (
        <Card><form onSubmit={save} className="space-y-3">
          <h2 className="font-bold">Ad code</h2>
          <Field label="Network name" maxLength={60} value={draft.networkName} onChange={(e) => setDraft({ ...draft, networkName: e.target.value })} />
          <TextArea label="Adsterra ad code" required rows={7} spellCheck={false} autoCapitalize="off" autoCorrect="off" maxLength={AD_CODE_MAX} className="font-mono text-xs"
            hint="Paste the whole snippet from Adsterra (the <script> tags). Only paste code you got from your own Adsterra account."
            value={draft.adCode} onChange={(e) => onCode(draft, e.target.value)} />
          {hasInsecureScript(draft.adCode) ? <Notice tone="warn">The code loads a script over plain http://. Browsers block this on an https website. Ask Adsterra for the https version.</Notice> : null}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Width (50–1200)" type="number" min={50} max={1200} value={draft.width} onChange={(e) => setDraft({ ...draft, width: e.target.value })} />
            <Field label="Height (30–600)" type="number" min={30} max={600} value={draft.height} onChange={(e) => setDraft({ ...draft, height: e.target.value })} />
          </div>
          <Select label="Show on" value={draft.device} onChange={(e) => setDraft({ ...draft, device: e.target.value })}>
            <option value="all">Phones and computers</option><option value="mobile">Phones only</option><option value="desktop">Computers only</option>
          </Select>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Starts (optional)" type="datetime-local" value={draft.startDate} onChange={(e) => setDraft({ ...draft, startDate: e.target.value })} />
            <Field label="Ends (optional)" type="datetime-local" value={draft.endDate} onChange={(e) => setDraft({ ...draft, endDate: e.target.value })} />
          </div>
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={draft.active} onChange={(e) => setDraft({ ...draft, active: e.target.checked })} /> Show this ad on the website</label>
          {formError ? <p role="alert" className="text-sm text-red-600">{formError}</p> : null}
          <div className="flex flex-wrap gap-2">
            <Button type="submit" loading={busy}>Save</Button>
            <Button variant="ghost" disabled={busy || !draft.adCode.trim()} onClick={() => setPreview(preview ? null : draft)}>{preview ? 'Hide preview' : 'Preview (runs the code in a sandbox)'}</Button>
            <Button variant="ghost" disabled={busy} onClick={() => { setDraft(null); setPreview(null); }}>Cancel</Button>
          </div>
          {preview ? (
            <div className="overflow-auto rounded-xl border border-dashed border-navy-100 p-2 dark:border-navy-500">
              <p className="mb-1 text-xs text-navy-500 dark:text-navy-100">Preview only. Adsterra may show nothing here if it only serves real visitors on your registered domain.</p>
              <iframe title="Ad preview" sandbox={SANDBOX} srcDoc={previewDoc(preview.adCode)} width={Number(preview.width) || 728} height={Number(preview.height) || 90} style={{ border: 0, maxWidth: '100%' }} />
            </div>
          ) : null}
        </form></Card>
      ) : null}
      {ads.length === 0 ? <EmptyState title="No ad configured">{isSuper ? 'Tap “Add ad code” to paste your Adsterra code.' : 'A super admin can add the ad code.'}</EmptyState> : ads.map((a) => (
        <Card key={a.id} className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="font-bold">{a.networkName || a.id} <span className="text-xs font-normal text-navy-500 dark:text-navy-100">· {a.width}×{a.height} · {a.device}</span></p>
            <p className="text-xs text-navy-500 dark:text-navy-100">{a.adCode ? describeCode(a.adCode) : 'uses a link instead of code'} · {fmtDate(a.startDate)} → {fmtDate(a.endDate)}</p>
          </div>
          <div className="flex items-center gap-2"><Badge tone={a.active ? 'green' : 'gray'}>{a.active ? 'on' : 'off'}</Badge>
            <Button small variant={a.active ? 'danger' : 'primary'} disabled={busy} onClick={() => void setActive(a, !a.active)}>{a.active ? 'Turn off' : 'Turn on'}</Button></div>
        </Card>
      ))}
    </>
  );
}
export default function AdsterraPage() { return <Require level="admin"><Inner /></Require>; }
