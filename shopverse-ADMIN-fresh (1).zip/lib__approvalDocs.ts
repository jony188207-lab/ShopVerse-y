/** Pure builder for the admin "Approve" button (no Firebase imports, so it is unit-testable). `ts` is the server-timestamp sentinel. Mirrors the customer app's self-activation: store id = applicant uid. */
export interface ApplicationFields { storeName: string; slug: string; description?: string; logoUrl?: string; bannerUrl?: string; city: string; country: string; returnPolicy?: string; shippingInfo?: string; phone: string; email: string; address: string }

export function buildApproval<T>(uid: string, adminId: string, a: ApplicationFields, ts: T) {
  return {
    application: { status: 'approved' as const, storeId: uid, reviewNote: '', reviewedBy: adminId, reviewedAt: ts, updatedAt: ts },
    role: { role: 'seller' as const, updatedAt: ts, updatedBy: adminId },
    store: {
      ownerId: uid, applicationId: uid, name: a.storeName, slug: a.slug, description: a.description ?? '', logoUrl: a.logoUrl ?? '', bannerUrl: a.bannerUrl ?? '',
      city: a.city, country: a.country, returnPolicy: a.returnPolicy ?? '', shippingInfo: a.shippingInfo ?? '', shippingFee: 0,
      status: 'approved' as const, ratingAvg: 0, ratingCount: 0, ratingSum: 0, followerCount: 0, salesCount: 0, createdAt: ts, updatedAt: ts,
    },
    storePrivate: { phone: a.phone, email: a.email, address: a.address, createdAt: ts, updatedAt: ts },
    slugClaim: { uid, createdAt: ts },
  };
}
export const buildRejection = <T,>(adminId: string, note: string, ts: T) => ({ status: 'rejected' as const, reviewNote: note, reviewedBy: adminId, reviewedAt: ts, updatedAt: ts });

/** In-app notification for the applicant (same shape the Cloud Functions write). Rules only allow these two types from an admin. */
export const buildNotification = <T,>(uid: string, approved: boolean, storeName: string, note: string, ts: T) => ({
  userId: uid, type: approved ? 'seller_approve' : 'seller_reject', category: 'system',
  title: approved ? 'Your store is approved' : 'Seller application not approved',
  body: (approved ? `“${storeName}” is live. Open the Seller Center to add products.` : note).slice(0, 300),
  image: '', relatedId: uid, relatedType: 'sellerApplication', link: approved ? '/seller' : '/become-seller', read: false, createdAt: ts,
});
