# What this panel expects from the customer-app repository
* `firestore.rules` and `firestore.indexes.json` deployed (the admin lists need the `status + createdAt desc` composite indexes).
* Cloud Functions (Blaze): `reviewSellerApplication`, `setUserStatus`, `setUserRole`, `reviewWithdrawal`, `confirmCodRemittance`, `sendAnnouncement`; region `us-central1`.
* Collections read/written: roles, users, sellerApplications, stores, storeFinance, products, reviews, videos, reports, orders, orderItems, withdrawals, categories, productBanners, platformSettings, publicSettings, announcements, adminLogs.
* Optional: the Cloudflare Worker (`../cloudflare-worker`) replaces the `reviewSellerApplication` function; it needs its own service-account secret (see its README).
* `adNetworkSettings/adsterra-bottom` is the bottom ad slot. Rules: only a super admin creates or changes the code; any admin can switch it on/off.
