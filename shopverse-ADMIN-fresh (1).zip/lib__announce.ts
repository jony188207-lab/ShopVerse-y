import { collection, doc, getDoc, getDocs, limit, query, serverTimestamp, where, writeBatch } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase/config';
import { friendlyError } from '@/lib/errors';
import { buildAnnouncementNotification, chunk, MAX_RECIPIENTS, type Audience } from '@/lib/notifyDocs';

/**
 * Send an in-app announcement straight from the Admin Panel: NO Cloud Function, NO Blaze plan. One notification document per recipient, written in batches
 * (the rules allow an admin to write only this fixed shape). In-app only: push messages need a server. Limited to 2,000 recipients per send.
 */
export async function sendAnnouncementDirect(a: { kind: 'promotion' | 'important'; audience: Audience; title: string; body: string; link: string; userId?: string }): Promise<{ recipients: number }> {
  const adminId = auth().currentUser?.uid;
  if (!adminId) throw new Error('Please sign in again.');
  try {
    let ids: string[] = [];
    if (a.audience === 'user') {
      const uid = (a.userId ?? '').trim();
      if (!uid || !(await getDoc(doc(db(), 'users', uid))).exists()) throw new Error('User not found. Check the user id.');
      ids = [uid];
    } else if (a.audience === 'sellers') {
      ids = (await getDocs(query(collection(db(), 'roles'), where('role', '==', 'seller'), limit(MAX_RECIPIENTS + 1)))).docs.map((d) => d.id);
    } else {
      ids = (await getDocs(query(collection(db(), 'users'), where('status', '==', 'active'), limit(MAX_RECIPIENTS + 1)))).docs.map((d) => d.id);
    }
    if (!ids.length) throw new Error('No recipients found for that audience.');
    if (ids.length > MAX_RECIPIENTS) throw new Error(`That audience is larger than ${MAX_RECIPIENTS}. Send to sellers or one user, or ask for the Worker/Cloud Function route.`);
    for (const part of chunk(ids)) {
      const b = writeBatch(db());
      part.forEach((uid) => b.set(doc(collection(db(), 'notifications')), buildAnnouncementNotification(uid, a.kind, a.title, a.body, a.link, serverTimestamp())));
      await b.commit();
    }
    const b = writeBatch(db());
    b.set(doc(collection(db(), 'announcements')), { audience: a.audience, kind: a.kind, title: a.title, body: a.body, link: a.link, recipients: ids.length, sentBy: adminId, createdAt: serverTimestamp() });
    b.set(doc(collection(db(), 'adminLogs')), { adminId, action: 'announcement.send', targetType: 'announcement', targetId: a.audience, note: `${a.kind}/${a.audience}: ${a.title} (${ids.length})`.slice(0, 300), createdAt: serverTimestamp() });
    await b.commit();
    return { recipients: ids.length };
  } catch (e) {
    if (e instanceof Error && !('code' in e)) throw e;
    if ((e as { code?: string })?.code === 'permission-denied') throw new Error('Firestore refused this. Publish the latest firestore.rules and make sure your account has the admin role.');
    throw new Error(friendlyError(e));
  }
}
