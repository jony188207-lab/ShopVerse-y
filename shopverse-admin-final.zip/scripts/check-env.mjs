// Prints which required NEXT_PUBLIC_* variables are missing. Reads .env.local if present. Never prints values.
import { existsSync, readFileSync } from 'node:fs';
const env = { ...process.env };
if (existsSync('.env.local')) {
  for (const line of readFileSync('.env.local', 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
const required = ['NEXT_PUBLIC_FIREBASE_API_KEY', 'NEXT_PUBLIC_FIREBASE_APP_ID', 'NEXT_PUBLIC_FIREBASE_PROJECT_ID', 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN'];
const missing = required.filter((k) => !env[k]);
if (env.NEXT_PUBLIC_FIREBASE_PROJECT_ID && env.NEXT_PUBLIC_FIREBASE_PROJECT_ID !== 'shopverse21-831fc') console.log('WARNING: project id is not shopverse21-831fc');
if (missing.length) { console.log('MISSING:\n  ' + missing.join('\n  ')); process.exit(1); }
console.log('All required variables are set.');
