const TONES: Record<string, string> = {
  green: 'bg-green-100 text-green-800', red: 'bg-red-100 text-red-800', amber: 'bg-amber-100 text-amber-900', purple: 'bg-brand-purple/15 text-brand-purple', gray: 'bg-navy-50 text-navy-700',
};
/** Maps common status words to a colour; unknown statuses are neutral. */
const AUTO: Record<string, string> = {
  approved: 'green', published: 'green', completed: 'green', resolved: 'green', delivered: 'green', active: 'green', visible: 'green',
  rejected: 'red', suspended: 'red', cancelled: 'red', hidden: 'red', returned: 'red', refunded: 'red',
  pending: 'amber', pending_review: 'amber', open: 'amber', under_review: 'amber', processing: 'purple',
};
export function Badge({ children, tone }: { children: string; tone?: keyof typeof TONES }) {
  const t = tone ?? AUTO[children] ?? 'gray';
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${TONES[t]}`}>{children.replace(/_/g, ' ')}</span>;
}
