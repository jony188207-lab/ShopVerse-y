import { addDoc, collection, doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';

/**
 * Rules (adminLogs): create only by staff, adminId == caller, createdAt == request.time, never updated or deleted.
 * Cloud Functions write their own log entries for the actions they perform.
 */
export interface AuditEntry { action: string; targetType: string; targetId: string; note?: string }
const entry = (adminId: string, e: AuditEntry) => ({ adminId, action: e.action, targetType: e.targetType, targetId: e.targetId, ...(e.note ? { note: e.note } : {}), createdAt: serverTimestamp() });

export const logAdmin = (adminId: string, e: AuditEntry) => addDoc(collection(db(), 'adminLogs'), entry(adminId, e));

/** Applies a document change and its audit entry in ONE atomic batch: no un-logged moderation can happen. */
export async function updateWithAudit(adminId: string, path: [string, string], changes: Record<string, unknown>, e: AuditEntry): Promise<void> {
  const batch = writeBatch(db());
  batch.update(doc(db(), path[0], path[1]), changes);
  batch.set(doc(collection(db(), 'adminLogs')), entry(adminId, e));
  await batch.commit();
}

/** Moderation field set accepted by the rules for products, reviews, videos (staff). */
export const moderationFields = (adminId: string, status: string, note: string) => ({
  status, moderationNote: note, moderatedBy: adminId, moderatedAt: serverTimestamp(), updatedAt: serverTimestamp(),
});
