import { toSlug } from '@/lib/format';

/**
 * The customer app shows this built-in list ONLY while the `categories` collection is empty. As soon as one category document exists,
 * the storefront shows only the documents. "Import built-in categories" (Categories page) copies this list so nothing disappears.
 * Keep in sync with config/categories.ts in the customer-app repository.
 */
export const DEFAULT_CATEGORY_NAMES = [
  'Electronics', 'Mobile & Accessories', 'Computers', 'Fashion', 'Beauty', 'Home & Living', 'Food & Grocery', 'Sports & Outdoors',
  'Toys & Games', 'Automotive', 'Books & Stationery', 'Health', 'Pets', 'Tools', 'Other',
];
export const DEFAULT_CATEGORIES = DEFAULT_CATEGORY_NAMES.map((name, i) => ({ id: toSlug(name), name, order: i * 10, active: true }));
