'use client';
import { useState } from 'react';
import { collection, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { moderationFields, updateWithAudit } from '@/lib/audit';
import { fmtDate, num, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'published' | 'hidden';
const TABS: { id: Tab; label: string }[] = [{ id: 'published', label: 'Published' }, { id: 'hidden', label: 'Hidden' }];
interface R { id: string; userName: string; userId: string; productId: string; rating: number; text: string; note: string; createdAt: unknown }
const mapR = (d: QueryDocumentSnapshot): R => {
  const x = d.data();
  return { id: d.id, userName: str(x.userName), userId: str(x.userId), productId: str(x.productId), rating: num(x.rating), text: str(x.text), note: str(x.moderationNote), createdAt: x.createdAt };
};

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('published');
  const [dialog, setDialog] = useState<R | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(tab, () => query(collection(db(), 'reviews'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapR);

  const moderate = async (r: R, status: 'published' | 'hidden', note: string) => {
    if (!user) return;
    setBusyId(r.id);
    try {
      await updateWithAudit(user.uid, ['reviews', r.id], moderationFields(user.uid, status, note), { action: `review.${status}`, targetType: 'review', targetId: r.id, note });
      toast(`Review ${status}.`, 'success');
      await list.reload();
    } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Reviews</h1>
      <Tabs label="Review status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No reviews here" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((r) => (
          <Card key={r.id} className="space-y-1">
            <div className="flex flex-wrap items-start justify-between gap-2"><p className="font-bold">{r.userName || 'Anonymous'} · {'★'.repeat(Math.max(0, Math.min(5, r.rating)))}<span className="text-navy-100">{'★'.repeat(Math.max(0, 5 - r.rating))}</span></p><Badge>{tab}</Badge></div>
            <p className="whitespace-pre-wrap text-sm">{r.text || '(no text)'}</p>
            <p className="break-all text-xs text-navy-500 dark:text-navy-100">{fmtDate(r.createdAt)} · product {r.productId} · user {r.userId}</p>
            {r.note ? <p className="text-sm"><span className="font-semibold">Note:</span> {r.note}</p> : null}
            <div className="pt-1">
              {tab === 'published' ? <Button small variant="danger" disabled={busyId === r.id} onClick={() => setDialog(r)}>Hide…</Button> : <Button small loading={busyId === r.id} onClick={() => void moderate(r, 'published', '').catch(() => undefined)}>Publish again</Button>}
            </div>
          </Card>
        ))}
      </ListStates>
      {dialog ? <ReasonDialog title="Hide this review" confirmLabel="Hide" danger onConfirm={(note) => moderate(dialog, 'hidden', note)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function ReviewsPage() { return <Require level="staff"><Inner /></Require>; }
