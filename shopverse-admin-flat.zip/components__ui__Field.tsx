import type { InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes, ReactNode } from 'react';

const base = 'w-full rounded-xl border border-navy-100 bg-white px-3 text-base text-navy-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-purple dark:border-navy-500 dark:bg-navy-900 dark:text-white';
const idOf = (label: string, id?: string) => id ?? `f-${label.replace(/\W+/g, '-').toLowerCase()}`;

interface InputProps extends InputHTMLAttributes<HTMLInputElement> { label: string; hint?: string }
export function Field({ label, hint, id, className = '', ...rest }: InputProps) {
  const fid = idOf(label, id);
  return (
    <div className="space-y-1">
      <label htmlFor={fid} className="text-sm font-medium">{label}</label>
      <input id={fid} className={`min-h-11 ${base} ${className}`} {...rest} />
      {hint ? <p className="text-xs text-navy-500 dark:text-navy-100">{hint}</p> : null}
    </div>
  );
}

interface AreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> { label: string; hint?: string }
export function TextArea({ label, hint, id, className = '', ...rest }: AreaProps) {
  const fid = idOf(label, id);
  return (
    <div className="space-y-1">
      <label htmlFor={fid} className="text-sm font-medium">{label}</label>
      <textarea id={fid} className={`min-h-24 py-2 ${base} ${className}`} {...rest} />
      {hint ? <p className="text-xs text-navy-500 dark:text-navy-100">{hint}</p> : null}
    </div>
  );
}

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> { label: string; children: ReactNode }
export function Select({ label, id, className = '', children, ...rest }: SelectProps) {
  const fid = idOf(label, id);
  return (
    <div className="space-y-1">
      <label htmlFor={fid} className="text-sm font-medium">{label}</label>
      <select id={fid} className={`min-h-11 ${base} ${className}`} {...rest}>{children}</select>
    </div>
  );
}
