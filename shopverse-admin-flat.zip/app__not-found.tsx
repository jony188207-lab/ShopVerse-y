import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-3 px-4 text-center">
      <h1 className="text-2xl font-extrabold">Page not found</h1>
      <p className="text-sm text-navy-500 dark:text-navy-100">This page does not exist in the ShopVerse Admin Panel.</p>
      <Link href="/" className="inline-flex min-h-11 items-center rounded-xl bg-brand-purple px-4 py-2 font-semibold text-white">Go to the dashboard</Link>
    </main>
  );
}
