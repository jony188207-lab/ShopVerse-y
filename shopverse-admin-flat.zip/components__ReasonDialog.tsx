'use client';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/Button';
import { TextArea } from '@/components/ui/Field';

/** Modal that asks for a written reason (the seller/user sees it, and it goes into the audit log). */
export function ReasonDialog({ title, confirmLabel, minLength = 5, required = true, danger = false, onConfirm, onClose }: {
  title: string; confirmLabel: string; minLength?: number; required?: boolean; danger?: boolean;
  onConfirm: (reason: string) => Promise<void>; onClose: () => void;
}) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && !busy) onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [busy, onClose]);
  const need = required ? minLength : 0;
  const submit = async () => {
    const r = reason.trim();
    if (r.length < need) { setError(`Write at least ${need} characters.`); return; }
    setBusy(true); setError('');
    try { await onConfirm(r); onClose(); } catch (e) { setError(e instanceof Error ? e.message : 'Failed.'); setBusy(false); }
  };
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className="w-full max-w-md space-y-3 rounded-card bg-white p-4 shadow-xl dark:bg-navy-700">
        <h2 className="text-lg font-bold">{title}</h2>
        <TextArea label={required ? 'Reason (required)' : 'Note (optional)'} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} autoFocus />
        {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={submit} loading={busy}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  );
}
