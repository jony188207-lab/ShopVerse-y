'use client';
import { useEffect, type ReactNode } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { atLeast, ROLE_LABEL } from '@/lib/permissions';
import { NAV } from '@/config/nav';
import { Button } from '@/components/ui/Button';
import { ErrorState, LoadingState } from '@/components/ui/States';

/** Gate + frame for every panel page: signed in AND staff, otherwise a clear message (never a blank page). */
export function Shell({ children }: { children: ReactNode }) {
  const { user, role, loading, configured, roleError, signOut } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (configured && !loading && !user) router.replace(`/login?next=${encodeURIComponent(pathname)}`);
  }, [configured, loading, user, router, pathname]);

  if (!configured) return <ErrorState title="Firebase is not configured" message="Set the NEXT_PUBLIC_FIREBASE_* variables (see .env.example) and rebuild." />;
  if (loading || !user) return <LoadingState />;
  const out = <Button variant="ghost" onClick={() => void signOut()}>Sign out</Button>;
  if (roleError) return <ErrorState title="Cannot verify your role" message={roleError} action={out} />;
  if (!atLeast(role, 'staff')) return <ErrorState title="No access" message={`${user.email ?? 'This account'} is not a ShopVerse moderator, admin or super admin. Roles are granted in the Firebase Console or by a super admin.`} action={out} />;

  const items = NAV.filter((n) => atLeast(role, n.level));
  const active = (href: string) => (href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(`${href}/`));
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[14rem,1fr]">
      <aside className="border-b border-navy-100 bg-white dark:border-navy-500 dark:bg-navy-700 lg:sticky lg:top-0 lg:h-screen lg:overflow-y-auto lg:border-b-0 lg:border-r">
        <div className="flex items-center justify-between gap-2 px-4 py-3">
          <div>
            <p className="text-base font-extrabold">ShopVerse <span className="text-brand-orange">Admin</span></p>
            <p className="max-w-[11rem] truncate text-xs text-navy-500 dark:text-navy-100">{user.email} · {ROLE_LABEL[role]}</p>
          </div>
          <button onClick={() => void signOut()} aria-label="Sign out" className="grid h-10 w-10 place-items-center rounded-lg border border-navy-100 dark:border-navy-500 lg:hidden"><LogOut className="h-4 w-4" /></button>
        </div>
        <nav aria-label="Admin sections" className="flex gap-1 overflow-x-auto px-2 pb-2 lg:flex-col lg:overflow-visible lg:pb-4">
          {items.map((n) => (
            <Link key={n.href} href={n.href} aria-current={active(n.href) ? 'page' : undefined}
              className={`shrink-0 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium ${active(n.href) ? 'bg-brand-purple text-white' : 'hover:bg-navy-50 dark:hover:bg-navy-900'}`}>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="hidden px-3 pb-4 lg:block"><Button variant="ghost" small className="w-full" onClick={() => void signOut()}><LogOut className="h-3.5 w-3.5" /> Sign out</Button></div>
      </aside>
      <main id="main" className="mx-auto w-full max-w-5xl space-y-4 px-4 py-5">{children}</main>
    </div>
  );
}
