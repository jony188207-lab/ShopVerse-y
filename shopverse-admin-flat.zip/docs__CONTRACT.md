# What this panel expects from the customer-app repository
* `firestore.rules` and `firestore.indexes.json` deployed (the admin lists need the `status + createdAt desc` composite indexes).
* Cloud Functions (Blaze): `reviewSellerApplication`, `setUserStatus`, `setUserRole`, `reviewWithdrawal`, `confirmCodRemittance`, `sendAnnouncement`; region `us-central1`.
* Collections read/written: roles, users, sellerApplications, stores, storeFinance, products, reviews, videos, reports, orders, orderItems, withdrawals, categories, productBanners, platformSettings, publicSettings, announcements, adminLogs.
