'use client';
import { collection, orderBy, query, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { fmtDate, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { Card } from '@/components/ui/Card';

interface L { id: string; adminId: string; action: string; targetType: string; targetId: string; note: string; createdAt: unknown }
const mapL = (d: QueryDocumentSnapshot): L => { const x = d.data(); return { id: d.id, adminId: str(x.adminId), action: str(x.action), targetType: str(x.targetType), targetId: str(x.targetId), note: str(x.note), createdAt: x.createdAt }; };

function Inner() {
  const list = usePagedQuery('logs', () => query(collection(db(), 'adminLogs'), orderBy('createdAt', 'desc')), mapL, 30);
  return (
    <>
      <h1 className="text-2xl font-extrabold">Audit log</h1>
      <p className="text-sm text-navy-500 dark:text-navy-100">Newest first. Entries cannot be edited or deleted from this panel.</p>
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No activity yet" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((l) => (
          <Card key={l.id}><p className="font-semibold">{l.action}</p><p className="break-all text-xs text-navy-500 dark:text-navy-100">{l.targetType} {l.targetId} · by {l.adminId} · {fmtDate(l.createdAt)}</p>{l.note ? <p className="text-sm">{l.note}</p> : null}</Card>
        ))}
      </ListStates>
    </>
  );
}
export default function LogsPage() { return <Require level="admin"><Inner /></Require>; }
