'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { collection, doc, getDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { friendlyError } from '@/lib/errors';
import { bool, num } from '@/lib/format';
import { Require } from '@/components/Require';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { ErrorState, LoadingState, Notice } from '@/components/ui/States';

interface S { commission: string; hold: string; minW: string; promoDays: string; push: boolean; ads: boolean; rotate: string }
const DEFAULTS: S = { commission: '10', hold: '7', minW: '10', promoDays: '14', push: true, ads: true, rotate: '5' };

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [s, setS] = useState<S | null>(null);
  const [error, setError] = useState('');
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError('');
    try {
      const [p, q] = await Promise.all([getDoc(doc(db(), 'platformSettings', 'main')), getDoc(doc(db(), 'publicSettings', 'main'))]);
      const a = p.data() ?? {}; const b = q.data() ?? {};
      setS({
        commission: String(num(a.commissionDefaultPercent, 10)), hold: String(num(a.earningsHoldDays, 7)), minW: String(num(a.minWithdrawal, 10)),
        promoDays: String(num(a.promotionMaxDays, 14)), push: a.pushEnabled === undefined ? true : bool(a.pushEnabled),
        ads: b.adsEnabled === undefined ? true : bool(b.adsEnabled), rotate: String(num(b.bannerRotateSeconds, 5)),
      });
    } catch (e) { setError(friendlyError(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!s || !user) return;
    const c = Number(s.commission), h = Number(s.hold), m = Number(s.minW), d = Number(s.promoDays), r = Number(s.rotate);
    if (!(c >= 0 && c <= 50)) return setFormError('Commission must be 0–50 %.');
    if (!Number.isInteger(h) || h < 0 || h > 60) return setFormError('Earnings hold must be a whole number of days, 0–60.');
    if (!(m >= 1 && m <= 100000)) return setFormError('Minimum withdrawal must be 1–100000.');
    if (!Number.isInteger(d) || d < 1 || d > 14) return setFormError('Promotion length must be a whole number of days, 1–14.');
    if (!Number.isInteger(r) || r < 2 || r > 30) return setFormError('Banner rotation must be a whole number of seconds, 2–30.');
    setFormError(''); setBusy(true);
    try {
      const batch = writeBatch(db());
      // Rules use hasOnly(...): write the complete document every time.
      batch.set(doc(db(), 'platformSettings', 'main'), { commissionDefaultPercent: c, earningsHoldDays: h, minWithdrawal: m, promotionMaxDays: d, pushEnabled: s.push, updatedAt: serverTimestamp(), updatedBy: user.uid });
      batch.set(doc(db(), 'publicSettings', 'main'), { adsEnabled: s.ads, bannerRotateSeconds: r, updatedAt: serverTimestamp(), updatedBy: user.uid });
      batch.set(doc(collection(db(), 'adminLogs')), { adminId: user.uid, action: 'settings.update', targetType: 'settings', targetId: 'main', createdAt: serverTimestamp() });
      await batch.commit();
      toast('Settings saved.', 'success');
    } catch (err) { setFormError(friendlyError(err)); } finally { setBusy(false); }
  };

  if (error) return <ErrorState message={error} action={<Button onClick={() => void load()}>Try again</Button>} />;
  if (!s) return <LoadingState />;
  const set = (p: Partial<S>) => setS({ ...s, ...p });
  return (
    <>
      <h1 className="text-2xl font-extrabold">Settings</h1>
      <Notice tone="warn">Super admin only. Changes apply to new activity; existing orders keep the rates they were created with. Whether the platform values are enforced depends on the Cloud Functions being deployed.</Notice>
      <form onSubmit={save} className="space-y-4">
        <Card className="space-y-3">
          <h2 className="font-bold">Platform</h2>
          <Field label="Default commission (%)" type="number" min={0} max={50} step="0.1" value={s.commission} onChange={(e) => set({ commission: e.target.value })} />
          <Field label="Earnings hold (days)" type="number" min={0} max={60} step={1} value={s.hold} onChange={(e) => set({ hold: e.target.value })} />
          <Field label="Minimum withdrawal" type="number" min={1} max={100000} value={s.minW} onChange={(e) => set({ minW: e.target.value })} />
          <Field label="Longest promotion (days)" type="number" min={1} max={14} step={1} value={s.promoDays} onChange={(e) => set({ promoDays: e.target.value })} />
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={s.push} onChange={(e) => set({ push: e.target.checked })} /> Push notifications enabled</label>
        </Card>
        <Card className="space-y-3">
          <h2 className="font-bold">Storefront</h2>
          <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={s.ads} onChange={(e) => set({ ads: e.target.checked })} /> Show ads / banners</label>
          <Field label="Banner rotation (seconds)" type="number" min={2} max={30} step={1} value={s.rotate} onChange={(e) => set({ rotate: e.target.value })} />
        </Card>
        {formError ? <p role="alert" className="text-sm text-red-600">{formError}</p> : null}
        <Button type="submit" loading={busy}>Save settings</Button>
      </form>
    </>
  );
}
export default function SettingsPage() { return <Require level="super"><Inner /></Require>; }
