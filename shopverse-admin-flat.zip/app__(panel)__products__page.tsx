'use client';
import { useState } from 'react';
import { collection, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { moderationFields, updateWithAudit } from '@/lib/audit';
import { fmtDate, fmtMoney, num, str, strList } from '@/lib/format';
import { storefrontUrl } from '@/lib/storefront';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'pending_review' | 'approved' | 'rejected' | 'suspended';
const TABS: { id: Tab; label: string }[] = [{ id: 'pending_review', label: 'Pending review' }, { id: 'approved', label: 'Approved' }, { id: 'rejected', label: 'Rejected' }, { id: 'suspended', label: 'Suspended' }];

interface P { id: string; title: string; price: number; stock: number; sellerId: string; storeId: string; categoryId: string; image: string; note: string; createdAt: unknown }
const mapP = (d: QueryDocumentSnapshot): P => {
  const x = d.data();
  return { id: d.id, title: str(x.title), price: num(x.price), stock: num(x.stock), sellerId: str(x.sellerId), storeId: str(x.storeId), categoryId: str(x.categoryId), image: strList(x.images)[0] ?? '', note: str(x.moderationNote), createdAt: x.createdAt };
};

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('pending_review');
  const [dialog, setDialog] = useState<{ p: P; status: 'rejected' | 'suspended' } | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(tab, () => query(collection(db(), 'products'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapP);

  // Staff may change ONLY status + moderation fields (rules: onlyChanges). The write and its audit entry are one atomic batch.
  const moderate = async (p: P, status: 'approved' | 'rejected' | 'suspended', note: string) => {
    if (!user) return;
    setBusyId(p.id);
    try {
      await updateWithAudit(user.uid, ['products', p.id], moderationFields(user.uid, status, note), { action: `product.${status}`, targetType: 'product', targetId: p.id, note });
      toast(`“${p.title}” → ${status}.`, 'success');
      await list.reload();
    } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Products</h1>
      <Tabs label="Product status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No products in this state" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((p) => (
          <Card key={p.id} className="flex gap-3">
            {p.image ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={p.image} alt="" loading="lazy" className="h-20 w-20 shrink-0 rounded-lg bg-navy-50 object-cover" /> : <div className="h-20 w-20 shrink-0 rounded-lg bg-navy-50 dark:bg-navy-900" />}
            <div className="min-w-0 flex-1 space-y-1">
              <div className="flex flex-wrap items-start justify-between gap-2"><p className="font-bold">{p.title}</p><Badge>{tab}</Badge></div>
              <p className="text-xs text-navy-500 dark:text-navy-100">{fmtMoney(p.price)} · stock {p.stock} · {p.categoryId} · {fmtDate(p.createdAt)}</p>
              <p className="break-all text-xs text-navy-500 dark:text-navy-100">seller {p.sellerId} · store {p.storeId}</p>
              {p.note ? <p className="text-sm"><span className="font-semibold">Note:</span> {p.note}</p> : null}
              <div className="flex flex-wrap gap-2 pt-1">
                {tab !== 'approved' ? <Button small loading={busyId === p.id} onClick={() => void moderate(p, 'approved', '').catch(() => undefined)}>{tab === 'suspended' ? 'Restore' : 'Approve'}</Button> : null}
                {tab === 'pending_review' ? <Button small variant="danger" disabled={busyId === p.id} onClick={() => setDialog({ p, status: 'rejected' })}>Reject…</Button> : null}
                {tab === 'approved' ? <Button small variant="danger" disabled={busyId === p.id} onClick={() => setDialog({ p, status: 'suspended' })}>Suspend…</Button> : null}
                {storefrontUrl(`/product/${p.id}`) ? <a className="inline-flex min-h-9 items-center text-xs text-brand-purple underline" href={storefrontUrl(`/product/${p.id}`)} target="_blank" rel="noopener noreferrer">View on storefront</a> : null}
              </div>
            </div>
          </Card>
        ))}
      </ListStates>
      {dialog ? <ReasonDialog title={`${dialog.status === 'rejected' ? 'Reject' : 'Suspend'} “${dialog.p.title}”`} confirmLabel={dialog.status === 'rejected' ? 'Reject' : 'Suspend'} danger
        onConfirm={(r) => moderate(dialog.p, dialog.status, r)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function ProductsPage() { return <Require level="staff"><Inner /></Require>; }
