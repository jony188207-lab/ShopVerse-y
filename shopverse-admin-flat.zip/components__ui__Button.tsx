import { forwardRef, type ButtonHTMLAttributes } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
const styles: Record<Variant, string> = {
  primary: 'bg-brand-orange text-white hover:brightness-95',
  secondary: 'bg-navy-900 text-white hover:bg-navy-700 dark:bg-white dark:text-navy-900',
  ghost: 'border border-navy-100 bg-transparent text-navy-900 hover:bg-navy-50 dark:border-navy-500 dark:text-white dark:hover:bg-navy-700',
  danger: 'bg-red-600 text-white hover:bg-red-700',
};

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: Variant; loading?: boolean; small?: boolean }

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = 'primary', loading, small, disabled, className = '', children, type = 'button', ...rest }, ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-purple disabled:cursor-not-allowed disabled:opacity-60 ${small ? 'min-h-9 px-3 text-xs' : 'min-h-11 px-5 text-sm'} ${styles[variant]} ${className}`}
      {...rest}
    >
      {loading ? 'Please wait…' : children}
    </button>
  );
});
