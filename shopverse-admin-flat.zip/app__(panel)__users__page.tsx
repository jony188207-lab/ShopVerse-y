'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { collection, doc, getDoc, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { setUserRole, setUserStatus } from '@/lib/callables';
import { fmtDate, str } from '@/lib/format';
import { atLeast, parseRole, ROLE_LABEL, type Role } from '@/lib/permissions';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field, Select } from '@/components/ui/Field';
import { Notice } from '@/components/ui/States';

interface U { id: string; email: string; name: string; status: string; suspendReason: string; createdAt: unknown }
const mapUser = (d: QueryDocumentSnapshot): U => {
  const x = d.data();
  return { id: d.id, email: str(x.email), name: str(x.displayName), status: str(x.status, 'active'), suspendReason: str(x.suspendReason), createdAt: x.createdAt };
};

function Inner() {
  const { role: myRole, user } = useAuth();
  const toast = useToast();
  const [emailFilter, setEmailFilter] = useState('');
  const [applied, setApplied] = useState('');
  const [roles, setRoles] = useState<Record<string, Role>>({});
  const [dialog, setDialog] = useState<U | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(`u:${applied}`, () => applied
    ? query(collection(db(), 'users'), where('email', '==', applied))
    : query(collection(db(), 'users'), orderBy('createdAt', 'desc')), mapUser);

  // Roles live in roles/{uid} (admins may read them). One small read per row on screen.
  useEffect(() => {
    const missing = list.items.filter((u) => roles[u.id] === undefined);
    if (!missing.length) return;
    let alive = true;
    void Promise.all(missing.map(async (u) => {
      try { const s = await getDoc(doc(db(), 'roles', u.id)); return [u.id, s.exists() ? parseRole(s.data().role) : 'user'] as const; } catch { return [u.id, 'user'] as const; }
    })).then((pairs) => { if (alive) setRoles((r) => ({ ...r, ...Object.fromEntries(pairs) })); });
    return () => { alive = false; };
  }, [list.items, roles]);

  const search = (e: FormEvent) => { e.preventDefault(); setApplied(emailFilter.trim().toLowerCase()); };
  const act = async (fn: () => Promise<unknown>, okMsg: string, id: string) => {
    setBusyId(id);
    try { await fn(); toast(okMsg, 'success'); await list.reload(); } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Users</h1>
      <Notice tone="warn">Suspending, reactivating and changing roles run through Cloud Functions (<code>setUserStatus</code>, <code>setUserRole</code>): the Firebase Auth account is disabled server-side. They need the Firebase Blaze plan. Role changes are super-admin only.</Notice>
      <form onSubmit={search} className="flex items-end gap-2">
        <div className="flex-1"><Field label="Find by exact email" type="email" value={emailFilter} onChange={(e) => setEmailFilter(e.target.value)} /></div>
        <Button type="submit">Search</Button>
        {applied ? <Button variant="ghost" onClick={() => { setEmailFilter(''); setApplied(''); }}>Clear</Button> : null}
      </form>
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No users found" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((u) => {
          const r = roles[u.id];
          const plain = r === 'user';
          return (
            <Card key={u.id} className="space-y-2">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div><p className="font-bold">{u.name || '(no name)'}</p><p className="text-xs text-navy-500 dark:text-navy-100">{u.email} · joined {fmtDate(u.createdAt)}</p><p className="break-all text-xs text-navy-500 dark:text-navy-100">uid {u.id}</p></div>
                <div className="flex gap-1"><Badge>{u.status}</Badge>{r ? <Badge tone={r === 'user' ? 'gray' : 'purple'}>{ROLE_LABEL[r]}</Badge> : null}</div>
              </div>
              {u.suspendReason ? <p className="text-sm"><span className="font-semibold">Suspended because:</span> {u.suspendReason}</p> : null}
              <div className="flex flex-wrap items-end gap-2">
                {u.status !== 'suspended'
                  ? <Button small variant="danger" disabled={!plain || busyId === u.id || u.id === user?.uid} onClick={() => setDialog(u)}>Suspend…</Button>
                  : <Button small loading={busyId === u.id} onClick={() => { if (window.confirm(`Reactivate ${u.email}?`)) void act(() => setUserStatus(u.id, 'active'), 'User reactivated.', u.id).catch(() => undefined); }}>Reactivate</Button>}
                {atLeast(myRole, 'super') && r && r !== 'seller' && r !== 'super_admin' && u.id !== user?.uid ? (
                  <div className="w-40"><Select label="Role" value={r} disabled={busyId === u.id} onChange={(e) => { const next = e.target.value as 'user' | 'moderator' | 'admin'; if (window.confirm(`Change ${u.email} to ${next}?`)) void act(() => setUserRole(u.id, next), 'Role updated.', u.id).catch(() => undefined); }}>
                    <option value="user">User</option><option value="moderator">Moderator</option><option value="admin">Admin</option>
                  </Select></div>
                ) : null}
              </div>
              {!plain && r ? <p className="text-xs text-navy-500 dark:text-navy-100">Sellers are suspended from the Sellers page; staff accounts cannot be suspended here.</p> : null}
            </Card>
          );
        })}
      </ListStates>
      {dialog ? <ReasonDialog title={`Suspend ${dialog.email}`} confirmLabel="Suspend" danger onConfirm={(r) => act(() => setUserStatus(dialog.id, 'suspended', r), 'User suspended.', dialog.id)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function UsersPage() { return <Require level="admin"><Inner /></Require>; }
