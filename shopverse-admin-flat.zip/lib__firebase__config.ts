import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getFunctions, type Functions } from 'firebase/functions';

// Literal process.env.NEXT_PUBLIC_* references are required so Next.js can inline them at build time.
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export const isFirebaseConfigured = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId);

export class FirebaseNotConfiguredError extends Error {
  constructor() {
    super('Firebase is not configured. Set the NEXT_PUBLIC_FIREBASE_* variables (see .env.example) and rebuild.');
    this.name = 'FirebaseNotConfiguredError';
  }
}

/** Lazy getters: importing this module never throws, so builds and tests work without credentials. */
export function getFirebaseApp(): FirebaseApp {
  if (!isFirebaseConfigured) throw new FirebaseNotConfiguredError();
  return getApps().length ? getApp() : initializeApp(firebaseConfig);
}
export const auth = (): Auth => getAuth(getFirebaseApp());
export const db = (): Firestore => getFirestore(getFirebaseApp());
export const functions = (): Functions => getFunctions(getFirebaseApp(), process.env.NEXT_PUBLIC_FIREBASE_FUNCTIONS_REGION || 'us-central1');
