'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { sendPasswordResetEmail, signInWithEmailAndPassword } from 'firebase/auth';
import { auth, isFirebaseConfigured } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { atLeast } from '@/lib/permissions';
import { friendlyError } from '@/lib/errors';
import { safeNextPath } from '@/lib/format';
import { Button } from '@/components/ui/Button';
import { Field } from '@/components/ui/Field';

export default function LoginPage() {
  const router = useRouter();
  const { user, role, loading, roleError, signOut } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  // Already signed in as staff: go straight to the panel (or the page that sent us here).
  useEffect(() => {
    if (!loading && user && atLeast(role, 'staff')) router.replace(safeNextPath(new URLSearchParams(window.location.search).get('next')));
  }, [loading, user, role, router]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(''); setInfo(''); setBusy(true);
    try { await signInWithEmailAndPassword(auth(), email.trim(), password); } catch (err) { setError(friendlyError(err)); } finally { setBusy(false); }
  };
  const reset = async () => {
    setError(''); setInfo('');
    if (!email.trim()) { setError('Type your email above first.'); return; }
    try { await sendPasswordResetEmail(auth(), email.trim()); } catch (err) {
      const msg = friendlyError(err);
      if (!/incorrect/i.test(msg)) { setError(msg); return; } // do not reveal whether an account exists
    }
    setInfo('If an account exists for that email, a reset link is on its way.');
  };

  if (!isFirebaseConfigured) return <main className="mx-auto max-w-sm p-6"><p role="alert" className="text-sm text-red-600">Firebase is not configured. Set the NEXT_PUBLIC_FIREBASE_* variables (see .env.example) and rebuild.</p></main>;
  return (
    <main className="mx-auto max-w-sm px-4 py-12">
      <form onSubmit={submit} className="space-y-4 rounded-card border border-navy-100 bg-white p-5 dark:border-navy-500 dark:bg-navy-700" aria-busy={busy}>
        <h1 className="text-2xl font-extrabold">ShopVerse <span className="text-brand-orange">Admin</span></h1>
        <p className="text-sm text-navy-500 dark:text-navy-100">Sign in with a moderator, admin or super admin account.</p>
        <Field label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <Field label="Password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        {error ? <p role="alert" className="text-sm text-red-600">{error}</p> : null}
        {info ? <p role="status" className="text-sm text-green-700 dark:text-green-400">{info}</p> : null}
        <Button type="submit" loading={busy} className="w-full">Sign in</Button>
        <button type="button" onClick={() => void reset()} className="text-sm text-brand-purple underline">Forgot password?</button>
      </form>
      {!loading && user && !atLeast(role, 'staff') ? (
        <div role="alert" className="mt-4 space-y-2 rounded-card border border-red-300 bg-white p-4 text-sm dark:bg-navy-700">
          <p>{roleError || `${user.email ?? 'This account'} is signed in but is not a moderator, admin or super admin.`}</p>
          <Button variant="ghost" small onClick={() => void signOut()}>Sign out</Button>
        </div>
      ) : null}
    </main>
  );
}
