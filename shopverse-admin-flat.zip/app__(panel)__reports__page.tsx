'use client';
import { useState } from 'react';
import { collection, orderBy, query, serverTimestamp, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { updateWithAudit } from '@/lib/audit';
import { fmtDate, str } from '@/lib/format';
import { storefrontUrl } from '@/lib/storefront';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Notice } from '@/components/ui/States';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'open' | 'under_review' | 'resolved' | 'rejected';
const TABS: { id: Tab; label: string }[] = [{ id: 'open', label: 'Open' }, { id: 'under_review', label: 'Under review' }, { id: 'resolved', label: 'Resolved' }, { id: 'rejected', label: 'Dismissed' }];
interface Rep { id: string; targetType: string; targetId: string; reason: string; evidence: string; reporterId: string; internalNote: string; resolution: string; createdAt: unknown }
const mapRep = (d: QueryDocumentSnapshot): Rep => {
  const x = d.data();
  return { id: d.id, targetType: str(x.targetType), targetId: str(x.targetId), reason: str(x.reason), evidence: str(x.evidence), reporterId: str(x.reporterId), internalNote: str(x.internalNote), resolution: str(x.resolution), createdAt: x.createdAt };
};
const TARGET_PATH: Record<string, string> = { product: '/product/', video: '/video/' };

function Inner() {
  const { user } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('open');
  const [dialog, setDialog] = useState<{ r: Rep; status: 'resolved' | 'rejected' } | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(tab, () => query(collection(db(), 'reports'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapRep);

  // Rules (staff update): only status, internalNote, resolution, action, resolvedBy, resolvedAt, updatedAt may change.
  const setStatus = async (r: Rep, status: Tab, note = '') => {
    if (!user) return;
    setBusyId(r.id);
    try {
      const changes: Record<string, unknown> = { status, updatedAt: serverTimestamp() };
      if (status === 'resolved' || status === 'rejected') { changes.resolution = note; changes.internalNote = note; changes.resolvedBy = user.uid; changes.resolvedAt = serverTimestamp(); }
      await updateWithAudit(user.uid, ['reports', r.id], changes, { action: `report.${status}`, targetType: 'report', targetId: r.id, note });
      toast(`Report → ${status.replace('_', ' ')}.`, 'success');
      await list.reload();
    } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Reports</h1>
      <Notice>Closing a report records your decision only. To act on the reported content, use the Products, Reviews, Videos, Sellers or Users pages.</Notice>
      <Tabs label="Report status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No reports here" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((r) => {
          const link = TARGET_PATH[r.targetType] ? storefrontUrl(`${TARGET_PATH[r.targetType]}${r.targetId}`) : '';
          return (
            <Card key={r.id} className="space-y-1">
              <div className="flex flex-wrap items-start justify-between gap-2"><p className="font-bold capitalize">{r.targetType} report</p><Badge>{tab}</Badge></div>
              <p className="text-sm"><span className="font-semibold">Reason:</span> {r.reason}</p>
              {r.evidence ? <p className="whitespace-pre-wrap text-sm"><span className="font-semibold">Evidence:</span> {r.evidence}</p> : null}
              <p className="break-all text-xs text-navy-500 dark:text-navy-100">{fmtDate(r.createdAt)} · target {r.targetId} · reporter {r.reporterId}</p>
              {r.resolution ? <p className="text-sm"><span className="font-semibold">Decision:</span> {r.resolution}</p> : null}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {tab === 'open' ? <Button small variant="ghost" loading={busyId === r.id} onClick={() => void setStatus(r, 'under_review').catch(() => undefined)}>Start review</Button> : null}
                {tab === 'open' || tab === 'under_review' ? <><Button small disabled={busyId === r.id} onClick={() => setDialog({ r, status: 'resolved' })}>Resolve…</Button><Button small variant="danger" disabled={busyId === r.id} onClick={() => setDialog({ r, status: 'rejected' })}>Dismiss…</Button></> : null}
                {link ? <a className="text-xs text-brand-purple underline" href={link} target="_blank" rel="noopener noreferrer">View reported item</a> : null}
              </div>
            </Card>
          );
        })}
      </ListStates>
      {dialog ? <ReasonDialog title={dialog.status === 'resolved' ? 'Resolve report' : 'Dismiss report'} confirmLabel={dialog.status === 'resolved' ? 'Resolve' : 'Dismiss'} danger={dialog.status === 'rejected'}
        onConfirm={(note) => setStatus(dialog.r, dialog.status, note)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function ReportsPage() { return <Require level="staff"><Inner /></Require>; }
