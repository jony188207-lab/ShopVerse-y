'use client';
import type { ReactNode } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { atLeast, type Level } from '@/lib/permissions';
import { ErrorState } from '@/components/ui/States';

const NEED: Record<Level, string> = { staff: 'moderator, admin or super admin', admin: 'admin or super admin', super: 'super admin' };

/** Page-level guard. UI only: Firestore rules and Cloud Functions enforce the same levels server-side. */
export function Require({ level, children }: { level: Level; children: ReactNode }) {
  const { role } = useAuth();
  if (!atLeast(role, level)) return <ErrorState title="No access" message={`This page needs the ${NEED[level]} role.`} />;
  return <>{children}</>;
}
