'use client';
import type { ReactNode } from 'react';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';

/** One consistent loading / error / empty / load-more wrapper for every paged list. */
export function ListStates({ loading, error, isEmpty, emptyTitle = 'Nothing here', emptyText, hasMore, onMore, onRetry, children }: {
  loading: boolean; error: string; isEmpty: boolean; emptyTitle?: string; emptyText?: string; hasMore: boolean; onMore: () => void; onRetry: () => void; children: ReactNode;
}) {
  if (error) return <ErrorState message={error} action={<Button onClick={onRetry}>Try again</Button>} />;
  if (loading && isEmpty) return <LoadingState />;
  if (!loading && isEmpty) return <EmptyState title={emptyTitle}>{emptyText}</EmptyState>;
  return (
    <div className="space-y-3">
      {children}
      {hasMore ? <div className="text-center"><Button variant="ghost" loading={loading} onClick={onMore}>Load more</Button></div> : null}
    </div>
  );
}
