// UI-level permission helpers. They only decide what to SHOW. The real enforcement is firestore.rules and the Cloud Functions' server-side role checks.
export type Role = 'user' | 'seller' | 'moderator' | 'admin' | 'super_admin';
export type Level = 'staff' | 'admin' | 'super';

const ROLES: Role[] = ['user', 'seller', 'moderator', 'admin', 'super_admin'];
export function parseRole(v: unknown): Role {
  return typeof v === 'string' && (ROLES as string[]).includes(v) ? (v as Role) : 'user';
}

const RANK: Record<Level, Role[]> = {
  staff: ['moderator', 'admin', 'super_admin'],
  admin: ['admin', 'super_admin'],
  super: ['super_admin'],
};
/** staff = moderator+ · admin = admin+ · super = super_admin only (mirrors isStaff / isAdmin / isSuper in firestore.rules). */
export const atLeast = (role: Role, level: Level): boolean => RANK[level].includes(role);

export const ROLE_LABEL: Record<Role, string> = { user: 'User', seller: 'Seller', moderator: 'Moderator', admin: 'Admin', super_admin: 'Super admin' };
