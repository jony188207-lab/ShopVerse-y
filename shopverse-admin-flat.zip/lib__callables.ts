import { httpsCallable } from 'firebase/functions';
import { functions } from '@/lib/firebase/config';
import { friendlyError } from '@/lib/errors';

/** Calls a deployed Cloud Function (callable). Throws an Error whose message is safe to show to the admin. */
export async function callFn<I, O = { ok: boolean }>(name: string, data: I): Promise<O> {
  try {
    return (await httpsCallable<I, O>(functions(), name)(data)).data;
  } catch (e) {
    throw new Error(friendlyError(e));
  }
}

// Payloads mirror functions/src in the customer-app repository.
export const reviewSellerApplication = (applicationId: string, action: 'approve' | 'reject' | 'suspend' | 'reactivate', note = '') =>
  callFn<{ applicationId: string; action: string; note: string }, { ok: boolean; storeId: string; products: number }>('reviewSellerApplication', { applicationId, action, note });
export const setUserStatus = (uid: string, status: 'active' | 'suspended', reason = '') => callFn('setUserStatus', { uid, status, reason });
export const setUserRole = (uid: string, role: 'user' | 'moderator' | 'admin') => callFn('setUserRole', { uid, role });
export const reviewWithdrawal = (id: string, status: 'approved' | 'processing' | 'completed' | 'rejected', note = '') => callFn('reviewWithdrawal', { id, status, note });
export const confirmCodRemittance = (orderId: string) => callFn('confirmCodRemittance', { orderId });
export const sendAnnouncement = (a: { kind: 'promotion' | 'important'; audience: 'all' | 'sellers' | 'user'; title: string; body: string; link: string; userId?: string }) =>
  callFn<typeof a, { recipients: number }>('sendAnnouncement', a);
