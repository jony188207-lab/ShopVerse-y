'use client';
import { useState } from 'react';
import Link from 'next/link';
import { collection, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { fmtDate, fmtMoney, num, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'all' | 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'return_requested';
const TABS: { id: Tab; label: string }[] = [
  { id: 'all', label: 'All' }, { id: 'pending', label: 'Pending' }, { id: 'confirmed', label: 'Confirmed' }, { id: 'processing', label: 'Processing' }, { id: 'shipped', label: 'Shipped' },
  { id: 'delivered', label: 'Delivered' }, { id: 'cancelled', label: 'Cancelled' }, { id: 'return_requested', label: 'Returns' },
];
interface O { id: string; orderNumber: string; storeName: string; status: string; total: number; currency: string; itemCount: number; codRemitted: boolean; createdAt: unknown }
const mapO = (d: QueryDocumentSnapshot): O => {
  const x = d.data();
  return { id: d.id, orderNumber: str(x.orderNumber, d.id), storeName: str(x.storeName), status: str(x.status), total: num(x.total), currency: str(x.currency, 'USD'), itemCount: num(x.itemCount), codRemitted: x.codRemitted === true, createdAt: x.createdAt };
};

function Inner() {
  const [tab, setTab] = useState<Tab>('all');
  const list = usePagedQuery(tab, () => tab === 'all'
    ? query(collection(db(), 'orders'), orderBy('createdAt', 'desc'))
    : query(collection(db(), 'orders'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapO);
  return (
    <>
      <h1 className="text-2xl font-extrabold">Orders</h1>
      <Tabs label="Order status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No orders here" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((o) => (
          <Link key={o.id} href={`/orders/${o.id}`} className="block">
            <Card className="flex flex-wrap items-center justify-between gap-2 hover:border-brand-purple">
              <div><p className="font-bold">{o.orderNumber}</p><p className="text-xs text-navy-500 dark:text-navy-100">{o.storeName} · {o.itemCount} item{o.itemCount === 1 ? '' : 's'} · {fmtDate(o.createdAt)}</p></div>
              <div className="flex items-center gap-2"><span className="font-semibold">{fmtMoney(o.total, o.currency)}</span><Badge>{o.status}</Badge>{o.status === 'delivered' && !o.codRemitted ? <Badge tone="amber">cash not confirmed</Badge> : null}</div>
            </Card>
          </Link>
        ))}
      </ListStates>
    </>
  );
}
export default function OrdersPage() { return <Require level="admin"><Inner /></Require>; }
