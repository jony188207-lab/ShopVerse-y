import { describe, expect, it } from 'vitest';
import { friendlyError } from './errors';

const err = (code: string, message: string) => Object.assign(new Error(message), { code });

describe('friendlyError', () => {
  it('explains an undeployed/unreachable function instead of showing "internal"', () => {
    expect(friendlyError(err('functions/internal', 'internal'))).toContain('probably not deployed');
    expect(friendlyError(err('functions/not-found', 'not-found'))).toContain('Blaze');
  });
  it('passes through readable messages raised by our own functions', () => {
    expect(friendlyError(err('functions/failed-precondition', 'Balance too low.'))).toBe('Balance too low.');
    expect(friendlyError(err('functions/permission-denied', 'Admins only.'))).toBe('Admins only.');
  });
  it('maps Firestore and Auth codes', () => {
    expect(friendlyError(err('permission-denied', 'x'))).toContain('security rules');
    expect(friendlyError(err('failed-precondition', 'x'))).toContain('index');
    expect(friendlyError(err('auth/invalid-credential', 'x'))).toBe('Email or password is incorrect.');
  });
  it('has a safe fallback', () => { expect(friendlyError('boom')).toBe('Something went wrong. Try again.'); });
});
