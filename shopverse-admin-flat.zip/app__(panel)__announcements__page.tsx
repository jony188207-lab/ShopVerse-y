'use client';
import { useState, type FormEvent } from 'react';
import { collection, orderBy, query, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { sendAnnouncement } from '@/lib/callables';
import { friendlyError } from '@/lib/errors';
import { fmtDate, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Field, Select, TextArea } from '@/components/ui/Field';
import { Notice } from '@/components/ui/States';

interface A { id: string; kind: string; audience: string; title: string; body: string; createdAt: unknown }
const mapA = (d: QueryDocumentSnapshot): A => { const x = d.data(); return { id: d.id, kind: str(x.kind), audience: str(x.audience), title: str(x.title), body: str(x.body), createdAt: x.createdAt }; };

function Inner() {
  const toast = useToast();
  const [kind, setKind] = useState<'promotion' | 'important'>('promotion');
  const [audience, setAudience] = useState<'all' | 'sellers' | 'user'>('all');
  const [title, setTitle] = useState(''); const [body, setBody] = useState(''); const [link, setLink] = useState(''); const [userId, setUserId] = useState('');
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const list = usePagedQuery('a', () => query(collection(db(), 'announcements'), orderBy('createdAt', 'desc')), mapA);

  const send = async (e: FormEvent) => {
    e.preventDefault();
    const t = title.trim(), b = body.trim(), l = link.trim(), u = userId.trim();
    if (!t || t.length > 100) return setErr('Title is required (max 100 characters).');
    if (!b || b.length > 500) return setErr('Message is required (max 500 characters).');
    if (l && !l.startsWith('/')) return setErr('The link must be a path inside the storefront, starting with “/”.');
    if (audience === 'user' && !u) return setErr('Enter the user id for a single-user message.');
    if (!window.confirm(`Send this to ${audience === 'all' ? 'ALL users' : audience === 'sellers' ? 'all sellers' : 'one user'}? It cannot be recalled.`)) return;
    setErr(''); setBusy(true);
    try {
      await sendAnnouncement({ kind, audience, title: t, body: b, link: l, ...(audience === 'user' ? { userId: u } : {}) });
      toast('Announcement sent.', 'success');
      setTitle(''); setBody(''); setLink(''); setUserId('');
      await list.reload();
    } catch (x) { setErr(friendlyError(x)); } finally { setBusy(false); }
  };

  return (
    <>
      <h1 className="text-2xl font-extrabold">Announcements</h1>
      <Notice tone="warn">Sending runs the <code>sendAnnouncement</code> Cloud Function, which needs the Blaze plan. On the free plan this fails with a clear message and nothing is sent.</Notice>
      <Card><form onSubmit={send} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <Select label="Type" value={kind} onChange={(e) => setKind(e.target.value as 'promotion' | 'important')}><option value="promotion">Promotion</option><option value="important">Important notice</option></Select>
          <Select label="Audience" value={audience} onChange={(e) => setAudience(e.target.value as 'all' | 'sellers' | 'user')}><option value="all">Everyone</option><option value="sellers">Sellers</option><option value="user">One user</option></Select>
        </div>
        {audience === 'user' ? <Field label="User id" value={userId} onChange={(e) => setUserId(e.target.value)} /> : null}
        <Field label="Title" maxLength={100} required value={title} onChange={(e) => setTitle(e.target.value)} />
        <TextArea label="Message" maxLength={500} required rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
        <Field label="Link (optional)" placeholder="/product/abc" value={link} onChange={(e) => setLink(e.target.value)} />
        {err ? <p role="alert" className="text-sm text-red-600">{err}</p> : null}
        <Button type="submit" loading={busy}>Send</Button>
      </form></Card>
      <h2 className="font-bold">Sent</h2>
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="Nothing sent yet" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((a) => (
          <Card key={a.id}><div className="flex flex-wrap items-center justify-between gap-2"><p className="font-bold">{a.title}</p><Badge>{a.kind} · {a.audience}</Badge></div><p className="text-sm">{a.body}</p><p className="text-xs text-navy-500 dark:text-navy-100">{fmtDate(a.createdAt)}</p></Card>
        ))}
      </ListStates>
    </>
  );
}
export default function AnnouncementsPage() { return <Require level="admin"><Inner /></Require>; }
