'use client';
export function Tabs<T extends string>({ tabs, value, onChange, label }: { tabs: { id: T; label: string }[]; value: T; onChange: (v: T) => void; label: string }) {
  return (
    <div role="tablist" aria-label={label} className="flex gap-1 overflow-x-auto rounded-xl bg-navy-50 p-1 dark:bg-navy-700">
      {tabs.map((t) => (
        <button key={t.id} type="button" role="tab" aria-selected={value === t.id} onClick={() => onChange(t.id)}
          className={`min-h-10 shrink-0 rounded-lg px-3 text-sm font-semibold ${value === t.id ? 'bg-white text-navy-900 shadow dark:bg-navy-900 dark:text-white' : 'text-navy-500 dark:text-navy-100'}`}>
          {t.label}
        </button>
      ))}
    </div>
  );
}
