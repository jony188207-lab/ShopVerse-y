'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { collection, getCountFromServer, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useAuth } from '@/hooks/useAuth';
import { atLeast, type Level } from '@/lib/permissions';
import { NEEDS_FUNCTIONS } from '@/config/nav';
import { Card } from '@/components/ui/Card';
import { Notice } from '@/components/ui/States';

interface Tile { id: string; label: string; href: string; level: Level; col: string; status: string }
const TILES: Tile[] = [
  { id: 'apps', label: 'Seller applications pending', href: '/sellers', level: 'admin', col: 'sellerApplications', status: 'pending' },
  { id: 'prod', label: 'Products awaiting review', href: '/products', level: 'staff', col: 'products', status: 'pending_review' },
  { id: 'vid', label: 'Videos awaiting review', href: '/videos', level: 'staff', col: 'videos', status: 'pending_review' },
  { id: 'rep', label: 'Open reports', href: '/reports', level: 'staff', col: 'reports', status: 'open' },
  { id: 'wd', label: 'Withdrawals pending', href: '/withdrawals', level: 'admin', col: 'withdrawals', status: 'pending' },
  { id: 'ord', label: 'Orders pending', href: '/orders', level: 'admin', col: 'orders', status: 'pending' },
];

export default function DashboardPage() {
  const { role } = useAuth();
  const [counts, setCounts] = useState<Record<string, number | 'error'>>({});
  const tiles = TILES.filter((t) => atLeast(role, t.level));

  useEffect(() => {
    let alive = true;
    tiles.forEach(async (t) => {
      try {
        const snap = await getCountFromServer(query(collection(db(), t.col), where('status', '==', t.status)));
        if (alive) setCounts((c) => ({ ...c, [t.id]: snap.data().count }));
      } catch {
        if (alive) setCounts((c) => ({ ...c, [t.id]: 'error' }));
      }
    });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role]);

  return (
    <>
      <h1 className="text-2xl font-extrabold">Dashboard</h1>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        {tiles.map((t) => {
          const c = counts[t.id];
          return (
            <Link key={t.id} href={t.href} className="block">
              <Card className="h-full hover:border-brand-purple">
                <p className="text-3xl font-extrabold">{c === undefined ? '…' : c === 'error' ? '—' : c}</p>
                <p className="mt-1 text-sm text-navy-500 dark:text-navy-100">{t.label}</p>
                {c === 'error' ? <p className="mt-1 text-xs text-red-600">Could not load (rules or connection)</p> : null}
              </Card>
            </Link>
          );
        })}
      </div>
      {atLeast(role, 'admin') ? (
        <Card className="space-y-2">
          <h2 className="font-bold">Which actions need Cloud Functions</h2>
          <p className="text-sm">These run on the server and fail with a clear message until the functions are deployed (they require the Firebase Blaze plan):</p>
          <ul className="list-disc pl-5 text-sm">{NEEDS_FUNCTIONS.map((x) => <li key={x}>{x}</li>)}</ul>
          <Notice>Moderation (products, reviews, videos, reports), categories, banners, store commission, settings and the audit log work with Firestore only.</Notice>
        </Card>
      ) : null}
    </>
  );
}
