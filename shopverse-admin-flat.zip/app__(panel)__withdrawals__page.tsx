'use client';
import { useState } from 'react';
import { collection, orderBy, query, where, type QueryDocumentSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { useToast } from '@/hooks/useToast';
import { usePagedQuery } from '@/hooks/usePagedQuery';
import { reviewWithdrawal } from '@/lib/callables';
import { fmtDate, fmtMoney, num, str } from '@/lib/format';
import { Require } from '@/components/Require';
import { ListStates } from '@/components/ListStates';
import { ReasonDialog } from '@/components/ReasonDialog';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Notice } from '@/components/ui/States';
import { Tabs } from '@/components/ui/Tabs';

type Tab = 'pending' | 'approved' | 'processing' | 'completed' | 'rejected';
type Next = 'approved' | 'processing' | 'completed' | 'rejected';
const TABS: { id: Tab; label: string }[] = [{ id: 'pending', label: 'Pending' }, { id: 'approved', label: 'Approved' }, { id: 'processing', label: 'Processing' }, { id: 'completed', label: 'Completed' }, { id: 'rejected', label: 'Rejected' }];
// Same transition table as functions/src/money.ts (the server re-checks it).
const FORWARD: Partial<Record<Tab, { to: Next; label: string }>> = { pending: { to: 'approved', label: 'Approve' }, approved: { to: 'processing', label: 'Mark processing' }, processing: { to: 'completed', label: 'Mark paid out' } };
const METHOD: Record<string, string> = { bank_transfer: 'Bank transfer', mobile_money: 'Mobile money', cash_pickup: 'Cash pickup' };

interface W { id: string; sellerId: string; storeName: string; amount: number; method: string; details: string; note: string; createdAt: unknown }
const mapW = (d: QueryDocumentSnapshot): W => {
  const x = d.data();
  return { id: d.id, sellerId: str(x.sellerId), storeName: str(x.storeName), amount: num(x.amount), method: str(x.method), details: str(x.details), note: str(x.note), createdAt: x.createdAt };
};

function Inner() {
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('pending');
  const [dialog, setDialog] = useState<W | null>(null);
  const [busyId, setBusyId] = useState('');
  const list = usePagedQuery(tab, () => query(collection(db(), 'withdrawals'), where('status', '==', tab), orderBy('createdAt', 'desc')), mapW);

  const run = async (w: W, status: Next, note = '') => {
    setBusyId(w.id);
    try { await reviewWithdrawal(w.id, status, note); toast(`Withdrawal ${status}.`, 'success'); await list.reload(); } catch (e) { toast(e instanceof Error ? e.message : 'Failed.', 'error'); throw e; } finally { setBusyId(''); }
  };
  const fwd = FORWARD[tab];

  return (
    <>
      <h1 className="text-2xl font-extrabold">Seller withdrawals</h1>
      <Notice tone="warn">Decisions run through the <code>reviewWithdrawal</code> Cloud Function, which moves the seller&apos;s balance inside a transaction (Blaze plan). “Mark paid out” means you really sent the money outside this app.</Notice>
      <Tabs label="Withdrawal status" tabs={TABS} value={tab} onChange={setTab} />
      <ListStates loading={list.loading} error={list.error} isEmpty={list.items.length === 0} emptyTitle="No withdrawals here" hasMore={list.hasMore} onMore={() => void list.loadMore()} onRetry={() => void list.reload()}>
        {list.items.map((w) => (
          <Card key={w.id} className="space-y-1">
            <div className="flex flex-wrap items-start justify-between gap-2"><p className="font-bold">{fmtMoney(w.amount)} · {w.storeName || 'Store'}</p><Badge>{tab}</Badge></div>
            <p className="text-xs text-navy-500 dark:text-navy-100">{METHOD[w.method] ?? w.method} · requested {fmtDate(w.createdAt)}</p>
            <p className="break-all text-xs text-navy-500 dark:text-navy-100">seller {w.sellerId}</p>
            <p className="whitespace-pre-wrap rounded-lg bg-navy-50 p-2 text-sm dark:bg-navy-900"><span className="font-semibold">Payout details:</span> {w.details}</p>
            {w.note ? <p className="text-sm"><span className="font-semibold">Note:</span> {w.note}</p> : null}
            {fwd || tab === 'pending' || tab === 'approved' || tab === 'processing' ? (
              <div className="flex flex-wrap gap-2 pt-1">
                {fwd ? <Button small loading={busyId === w.id} onClick={() => { if (window.confirm(`${fwd.label}: ${fmtMoney(w.amount)} for ${w.storeName || w.sellerId}?`)) void run(w, fwd.to).catch(() => undefined); }}>{fwd.label}</Button> : null}
                <Button small variant="danger" disabled={busyId === w.id} onClick={() => setDialog(w)}>Reject…</Button>
              </div>
            ) : null}
          </Card>
        ))}
      </ListStates>
      {dialog ? <ReasonDialog title={`Reject ${fmtMoney(dialog.amount)} withdrawal`} confirmLabel="Reject" danger onConfirm={(r) => run(dialog, 'rejected', r)} onClose={() => setDialog(null)} /> : null}
    </>
  );
}
export default function WithdrawalsPage() { return <Require level="admin"><Inner /></Require>; }
