import { describe, expect, it } from 'vitest';
import { atLeast, parseRole } from './permissions';

describe('parseRole', () => {
  it('accepts known roles and falls back to user for anything else', () => {
    expect(parseRole('admin')).toBe('admin');
    expect(parseRole('super_admin')).toBe('super_admin');
    expect(parseRole('root')).toBe('user');
    expect(parseRole(undefined)).toBe('user');
    expect(parseRole(5)).toBe('user');
  });
});
describe('atLeast (mirrors isStaff / isAdmin / isSuper in the rules)', () => {
  it('staff = moderator, admin, super_admin', () => {
    expect(atLeast('moderator', 'staff')).toBe(true);
    expect(atLeast('seller', 'staff')).toBe(false);
    expect(atLeast('user', 'staff')).toBe(false);
  });
  it('admin = admin and super_admin only', () => {
    expect(atLeast('moderator', 'admin')).toBe(false);
    expect(atLeast('admin', 'admin')).toBe(true);
    expect(atLeast('super_admin', 'admin')).toBe(true);
  });
  it('super = super_admin only', () => {
    expect(atLeast('admin', 'super')).toBe(false);
    expect(atLeast('super_admin', 'super')).toBe(true);
  });
});
