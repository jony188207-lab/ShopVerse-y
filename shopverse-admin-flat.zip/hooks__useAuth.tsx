'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { onAuthStateChanged, signOut as fbSignOut, type User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db, isFirebaseConfigured } from '@/lib/firebase/config';
import { parseRole, type Role } from '@/lib/permissions';

interface AuthState {
  user: User | null;
  role: Role;
  loading: boolean;
  configured: boolean;
  /** Set when the role document could not be read (rules not deployed, offline...). The panel then refuses access instead of guessing. */
  roleError: string;
  signOut: () => Promise<void>;
}
const Ctx = createContext<AuthState | null>(null);

/** Firebase Auth persists the session itself (IndexedDB). The role comes from roles/{uid}, the same document the rules and functions use. */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<Role>('user');
  const [roleError, setRoleError] = useState('');
  const [loading, setLoading] = useState(isFirebaseConfigured);

  useEffect(() => {
    if (!isFirebaseConfigured) return;
    return onAuthStateChanged(auth(), async (u) => {
      setUser(u);
      setRoleError('');
      if (!u) { setRole('user'); setLoading(false); return; }
      setLoading(true);
      try {
        const snap = await getDoc(doc(db(), 'roles', u.uid));
        setRole(snap.exists() ? parseRole(snap.data().role) : 'user');
      } catch {
        setRole('user');
        setRoleError('Could not read your role. Check that firestore.rules are deployed and that you are online.');
      }
      setLoading(false);
    });
  }, []);

  const signOut = useCallback(async () => { await fbSignOut(auth()); }, []);
  const value = useMemo(() => ({ user, role, loading, configured: isFirebaseConfigured, roleError, signOut }), [user, role, loading, roleError, signOut]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside <AuthProvider>');
  return v;
}
