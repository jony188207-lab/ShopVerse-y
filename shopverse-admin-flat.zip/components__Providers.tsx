'use client';
import type { ReactNode } from 'react';
import { AuthProvider } from '@/hooks/useAuth';
import { ToastProvider } from '@/hooks/useToast';

export function Providers({ children }: { children: ReactNode }) {
  return <AuthProvider><ToastProvider>{children}</ToastProvider></AuthProvider>;
}
